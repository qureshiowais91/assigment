// Title
// - Body
// - Created By
// - Active/Inactive
// - Geo location (latitude and longitude

const mongoose = require("mongoose");


const User = new mongoose.Schema({
    title: {
        type: String,
        require: true
    },
    password:{
        type:String
    }
})



module.exports = mongoose.model('User', User);

