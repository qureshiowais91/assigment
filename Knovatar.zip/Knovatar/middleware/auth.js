const User = require("../models/user.js");
const jwt = require("jsonwebtoken");
async function auth(req, res,next) {
    const auth = req.headers.authorization;
    console.log(auth)

    const user = await jwt.verify(auth, "123123");
    console.log(user)
    if (!user) {
        res.status(304).json("unauth");
    }
    
    req.user = await User.findById(user.id);
    next()
}


module.exports = auth