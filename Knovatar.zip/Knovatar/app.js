
const express = require('express');
const cors = require('cors');
const bcryptjs = require('bcryptjs');
const connectDB = require("./services/connectDB")
const app = express();
const User = require("./models/user");
const jwt = require("jsonwebtoken");
const auth = require('./middleware/auth')

require("dotenv").config()

app.use(cors());
app.use(express.json())
const PORT = process.env.PORT || 3000;


connectDB()

app.get("/api", async (req, res) => {
  const salt = await bcryptjs.genSalt();
  const password = await bcryptjs.hash("123123", salt);
  const UserOBJ = await User.create({ title: "test", password: password })
  const token = await jwt.sign({ id: UserOBJ._id }, "123123");
  res.status(200).json({ UserOBJ, token })
})


app.post("/api/auth",auth,async (req, res) => {
  res.status(200).json(req.user)
})

console.log(PORT)
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});